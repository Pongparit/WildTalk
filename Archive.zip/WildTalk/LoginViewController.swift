//
//  ViewController.swift
//  WildTalk
//
//  Created by Pongparit Paocharoen on 3/7/17.
//  Copyright © 2017 Pongparit Paocharoen. All rights reserved.
//

import UIKit
import FirebaseAuth
import GoogleSignIn

class LoginViewController: UIViewController {
    
    private var authListener: FIRAuthStateDidChangeListenerHandle?
    
    // MARK: View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        GIDSignIn.sharedInstance().uiDelegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        authListener = FIRAuth.auth()?.addStateDidChangeListener({ (auth, user) in
            if let user = user {
//                print(user)
                
                // Go to chat view controller.
                let nav = self.storyboard?.instantiateViewController(withIdentifier: "NavChatViewController") as! UINavigationController
                let chatVC = nav.viewControllers[0] as! ChatViewController
                chatVC.senderId = user.uid
                chatVC.senderDisplayName = user.displayName
                chatVC.avatarString = user.photoURL?.absoluteString ?? ""
                chatVC.title = "WildTalk"
                let appDelegate = UIApplication.shared.delegate as! AppDelegate
                appDelegate.window?.rootViewController = nav
            }
        })
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        FIRAuth.auth()?.removeStateDidChangeListener(authListener!)
    }
    
}

// MARK: - GIDSignInUIDelegate
extension LoginViewController: GIDSignInUIDelegate {
    
}
